// const mongoose = require("mongoose")

// const AdminServicesSchema = new mongoose.Schema({ 
//   AdminServices: { type: String, required: true },
// }, { timestamps: true }); 

// const AdminSpiritualServices = mongoose.model("AddAdminServices", AdminServicesSchema);
// module.exports = AdminSpiritualServices;